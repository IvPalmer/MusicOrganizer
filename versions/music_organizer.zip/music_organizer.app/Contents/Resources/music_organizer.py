# music_organizer.py
import os
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import queue

from discogs_utils import create_discogs_client
import organizer

# Opens the SoundCloud page in the default web browser.
def open_soundcloud():
    webbrowser.open("https://soundcloud.com/ivpalmer")

# Opens the given folder using the OS default file explorer.
def open_folder(folder_path):
    try:
        if os.name == "nt":  # Windows
            os.startfile(folder_path)
        elif os.name == "posix":  # macOS or Linux
            os.system(f"open '{folder_path}'")
        else:
            messagebox.showinfo("Notification", "Your OS is not supported for opening folders.")
    except Exception as e:
        print(f"Error opening folder: {e}")

def main():
    # Initialize Tkinter window.
    root = tk.Tk()
    root.title("Music Organizer")
    root.geometry("700x700")
    root.resizable(False, False)

    selected_folder = tk.StringVar(value="No folder selected")
    log_queue = queue.Queue()

    def scale_font(size):
        return size  # This function can be extended for dynamic scaling if needed.

    # Main container for the UI elements.
    container = tk.Frame(root)
    container.pack(expand=True, fill="both")

    # Discogs API token input.
    tk.Label(container, text="Discogs API Token:", font=("Helvetica", scale_font(16))).pack(pady=(20, 10))
    token_entry = tk.Entry(container, width=40, font=("Helvetica", scale_font(14)))
    token_entry.pack(pady=(0, 15))

    def open_discogs_link():
        webbrowser.open("https://www.discogs.com/settings/developers")
    tk.Button(container, text="Find Your Token Here", command=open_discogs_link, font=("Helvetica", scale_font(14))).pack(pady=(0, 25))

    # Radio buttons for selecting whether to move or copy files.
    tk.Label(container, text="Select Action:", font=("Helvetica", scale_font(16))).pack(pady=(5, 5))
    action_var = tk.StringVar(value="move")
    options_frame = tk.Frame(container)
    options_frame.pack(pady=(0, 15))
    tk.Radiobutton(options_frame, text="Move Files", variable=action_var, value="move", font=("Helvetica", scale_font(14))).grid(row=0, column=0, padx=10)
    tk.Radiobutton(options_frame, text="Copy Files", variable=action_var, value="copy", font=("Helvetica", scale_font(14))).grid(row=0, column=1, padx=10)

    tk.Label(container, text="WARNING: DJ Softwares might lose reference if you move files", 
             font=("Helvetica", scale_font(12)), fg="red").pack(pady=(0, 15))

    # Folder selection UI.
    folder_frame = tk.Frame(container)
    folder_frame.pack(pady=(5, 15))
    tk.Button(folder_frame, text="Select Music Folder", command=lambda: select_folder(selected_folder),
              font=("Helvetica", scale_font(14))).grid(row=0, column=0, padx=15)
    tk.Label(folder_frame, textvariable=selected_folder, font=("Helvetica", scale_font(12)), wraplength=600, anchor="w", justify="left").grid(row=0, column=1, sticky="w")

    # Progress bar.
    progress = ttk.Progressbar(container, orient="horizontal", length=600, mode="determinate")
    progress.pack(pady=(10, 15))

    # Log display window.
    log_window = tk.Text(container, height=15, width=80, state="disabled", bg="black", fg="white", font=("Helvetica", scale_font(12)))
    log_window.pack(pady=(5, 15))

    # Callback to add messages to the log (and print debug info to console).
    def log_message(message):
        log_queue.put(message)
        print(f"[DEBUG]: {message}")

    # Periodically update the log window with queued messages.
    def update_log():
        while not log_queue.empty():
            message = log_queue.get_nowait()
            log_window["state"] = "normal"
            log_window.insert("end", f"{message}\n")
            log_window["state"] = "disabled"
            log_window.see("end")
        root.after(100, update_log)

    # Opens a folder selection dialog.
    def select_folder(selected_folder_var):
        folder = filedialog.askdirectory(title="Select your music folder")
        if folder:
            selected_folder_var.set(folder)

    # Callback for updating the progress bar.
    def progress_callback(current, total):
        progress["maximum"] = total
        progress["value"] = current
        root.update_idletasks()

    # Launches the file organization process in a separate thread.
    def start_organizing_threaded(user_token, folder, action):
        # Disable the start button to prevent multiple threads from starting.
        start_button.config(state=tk.DISABLED)
        def task():
            try:
                client = create_discogs_client(user_token)
            except Exception as e:
                log_message(f"Error initializing Discogs client: {e}")
                start_button.config(state=tk.NORMAL)
                return
            organizer.organize_files(client, folder, action, log_callback=log_message, progress_callback=progress_callback)
            open_folder(folder)
            start_button.config(state=tk.NORMAL)
        threading.Thread(target=task).start()

    start_button = tk.Button(container, text="Start Organizing", 
                             command=lambda: start_organizing_threaded(
                                 token_entry.get(), selected_folder.get(), action_var.get()), 
                             font=("Helvetica", scale_font(14)))
    start_button.pack(pady=(5, 15))

    tk.Button(container, text="Follow Me on SoundCloud", command=open_soundcloud, font=("Helvetica", scale_font(14))).pack(pady=(0, 15))

    update_log()
    root.mainloop()

if __name__ == "__main__":
    main()